<?php 
$schema['central']['customers']['items']['sd_units.units'] = [
    'href' => 'units.manage_units',                   
    'position' => 100,
];

return $schema;

?>
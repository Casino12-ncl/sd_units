-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Авг 23 2022 г., 15:07
-- Версия сервера: 10.6.8-MariaDB
-- Версия PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `cscart1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_units`
--

CREATE TABLE `cscart_units` (
  `unit_id` int(11) UNSIGNED NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'A',
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `upd_timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `slave_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_units`
--

INSERT INTO `cscart_units` (`unit_id`, `status`, `timestamp`, `upd_timestamp`, `user_id`, `slave_id`) VALUES
(1, 'D', 1661029200, 0, 2, '2'),
(2, 'A', 1661029200, 0, 4, '2'),
(3, 'A', 1661029200, 0, 2, '3'),
(4, 'A', 1661029200, 0, 3, '2,3,4');

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_unit_descriptions`
--

CREATE TABLE `cscart_unit_descriptions` (
  `unit_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `lang_code` char(2) NOT NULL DEFAULT '',
  `unit` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_unit_descriptions`
--

INSERT INTO `cscart_unit_descriptions` (`unit_id`, `lang_code`, `unit`, `description`) VALUES
(1, 'ru', 'hidden unit 1', ''),
(2, 'ru', 'unit 4', ''),
(3, 'ru', 'unit 3', ''),
(4, 'ru', 'unit 2', '');

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_usergroups`
--

CREATE TABLE `cscart_usergroups` (
  `usergroup_id` mediumint(8) UNSIGNED NOT NULL,
  `status` char(1) NOT NULL DEFAULT '',
  `type` char(1) NOT NULL DEFAULT 'C',
  `company_id` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_usergroups`
--

INSERT INTO `cscart_usergroups` (`usergroup_id`, `status`, `type`, `company_id`) VALUES
(3, 'D', 'C', 0),
(4, 'A', 'A', 0),
(5, 'A', 'A', 0),
(6, 'A', 'A', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_usergroup_descriptions`
--

CREATE TABLE `cscart_usergroup_descriptions` (
  `usergroup_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `lang_code` char(2) NOT NULL DEFAULT '',
  `usergroup` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_usergroup_descriptions`
--

INSERT INTO `cscart_usergroup_descriptions` (`usergroup_id`, `lang_code`, `usergroup`) VALUES
(3, 'ru', 'Оптовый'),
(4, 'ru', 'Администратор'),
(5, 'ru', 'Content manager'),
(6, 'ru', 'Sales manager');

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_usergroup_links`
--

CREATE TABLE `cscart_usergroup_links` (
  `link_id` mediumint(8) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `usergroup_id` mediumint(8) UNSIGNED NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'D'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_users`
--

CREATE TABLE `cscart_users` (
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'A',
  `user_type` char(1) NOT NULL DEFAULT 'C',
  `user_login` varchar(255) NOT NULL DEFAULT '',
  `referer` varchar(255) NOT NULL DEFAULT '',
  `is_root` char(1) NOT NULL DEFAULT 'N',
  `company_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `last_login` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `last_activity` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `salt` varchar(10) NOT NULL DEFAULT '',
  `firstname` varchar(128) NOT NULL DEFAULT '',
  `lastname` varchar(128) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `phone` varchar(128) NOT NULL DEFAULT '',
  `fax` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(128) NOT NULL DEFAULT '',
  `tax_exempt` char(1) NOT NULL DEFAULT 'N',
  `lang_code` char(2) NOT NULL DEFAULT '',
  `birthday` int(11) NOT NULL DEFAULT 0,
  `purchase_timestamp_from` int(11) NOT NULL DEFAULT 0,
  `purchase_timestamp_to` int(11) NOT NULL DEFAULT 0,
  `responsible_email` varchar(80) NOT NULL DEFAULT '',
  `password_change_timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `api_key` varchar(255) NOT NULL DEFAULT '',
  `helpdesk_user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `janrain_identifier` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_users`
--

INSERT INTO `cscart_users` (`user_id`, `status`, `user_type`, `user_login`, `referer`, `is_root`, `company_id`, `last_login`, `last_activity`, `timestamp`, `password`, `salt`, `firstname`, `lastname`, `company`, `email`, `phone`, `fax`, `url`, `tax_exempt`, `lang_code`, `birthday`, `purchase_timestamp_from`, `purchase_timestamp_to`, `responsible_email`, `password_change_timestamp`, `api_key`, `helpdesk_user_id`, `janrain_identifier`) VALUES
(1, 'A', 'A', 'admin', '', 'Y', 0, 1661104848, 1661265057, 1661104455, '$2y$10$JgYI4tICnfxAPEEy3RJLUe0OgSHa2BBoF4rzly2o0zZMDIlRmsOnW', 'HL+[r.=gC6', 'Admin', 'Admin', 'Your company', 'istomin_84@mail.ru', '55 55 5555 5555', '', '', 'N', 'ru', 0, 0, 0, '', 1661104455, '', 0, ''),
(2, 'A', 'C', 'user_2', '', 'N', 1, 0, 0, 1661105139, '$2y$10$MZ/J/HII1k/5t..0XVywJOG/bQwDSNQE/OyIRCjw68nbC82mtzVUK', '', 'ivan', 'ivanov', '', 'ivan@1.ru', '', '', '', 'N', 'ru', 0, 0, 0, '', 1661105139, '', 0, ''),
(3, 'A', 'C', 'user_3', '', 'N', 1, 0, 0, 1661262711, '$2y$10$TJFGLZHTN2hpX/fIQ/nu8Ot.3xon.hkYm9BvvaSeQ7z88qKL1B0Ja', '', 'fedya', 'fedorov', '', 'fedya@1.ru', '', '', '', 'N', 'ru', 0, 0, 0, '', 1661262711, '', 0, ''),
(4, 'A', 'C', 'user_4', '', 'N', 1, 0, 0, 1661262807, '$2y$10$8Hxf3b4Aw9Xq.anYmgNW5OYcNM1EPV/DYz3/vQjdO7v/84bJ5v9tC', '', 'petya', 'petrov', '', 'petya@1.ru', '', '', '', 'N', 'ru', 0, 0, 0, '', 1661262807, '', 0, '');

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_user_data`
--

CREATE TABLE `cscart_user_data` (
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `type` char(1) NOT NULL DEFAULT '',
  `data` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_user_data`
--

INSERT INTO `cscart_user_data` (`user_id`, `type`, `data`) VALUES
(1, 'L', 'a:3:{i:445266333;a:4:{s:4:\"func\";a:2:{i:0;s:16:\"fn_get_user_name\";i:1;s:1:\"2\";}s:3:\"url\";s:81:\"admin.php?dispatch=profiles.update&user_id=2&user_type=C&selected_section=general\";s:4:\"icon\";s:0:\"\";s:4:\"text\";s:4:\"user\";}i:1837959435;a:4:{s:4:\"func\";a:2:{i:0;s:16:\"fn_get_user_name\";i:1;s:1:\"3\";}s:3:\"url\";s:81:\"admin.php?dispatch=profiles.update&user_id=3&user_type=C&selected_section=general\";s:4:\"icon\";s:0:\"\";s:4:\"text\";s:4:\"user\";}i:4092173480;a:4:{s:4:\"func\";a:2:{i:0;s:16:\"fn_get_user_name\";i:1;s:1:\"4\";}s:3:\"url\";s:81:\"admin.php?dispatch=profiles.update&user_id=4&user_type=C&selected_section=general\";s:4:\"icon\";s:0:\"\";s:4:\"text\";s:4:\"user\";}}');

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_user_last_passwords`
--

CREATE TABLE `cscart_user_last_passwords` (
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `last_password` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_user_mailing_lists`
--

CREATE TABLE `cscart_user_mailing_lists` (
  `subscriber_id` mediumint(8) UNSIGNED NOT NULL,
  `list_id` mediumint(8) UNSIGNED NOT NULL,
  `activation_key` varchar(32) NOT NULL DEFAULT '',
  `unsubscribe_key` varchar(32) NOT NULL DEFAULT '',
  `confirmed` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_user_profiles`
--

CREATE TABLE `cscart_user_profiles` (
  `profile_id` mediumint(8) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `profile_type` char(1) NOT NULL DEFAULT 'P',
  `b_firstname` varchar(128) NOT NULL DEFAULT '',
  `b_lastname` varchar(128) NOT NULL DEFAULT '',
  `b_address` varchar(255) NOT NULL DEFAULT '',
  `b_address_2` varchar(255) NOT NULL DEFAULT '',
  `b_city` varchar(64) NOT NULL DEFAULT '',
  `b_county` varchar(32) NOT NULL DEFAULT '',
  `b_state` varchar(32) NOT NULL DEFAULT '',
  `b_country` char(2) NOT NULL DEFAULT '',
  `b_zipcode` varchar(16) NOT NULL DEFAULT '',
  `b_phone` varchar(128) NOT NULL DEFAULT '',
  `s_firstname` varchar(128) NOT NULL DEFAULT '',
  `s_lastname` varchar(128) NOT NULL DEFAULT '',
  `s_address` varchar(255) NOT NULL DEFAULT '',
  `s_address_2` varchar(255) NOT NULL DEFAULT '',
  `s_city` varchar(255) NOT NULL DEFAULT '',
  `s_county` varchar(32) NOT NULL DEFAULT '',
  `s_state` varchar(32) NOT NULL DEFAULT '',
  `s_country` char(2) NOT NULL DEFAULT '',
  `s_zipcode` varchar(16) NOT NULL DEFAULT '',
  `s_phone` varchar(128) NOT NULL DEFAULT '',
  `s_address_type` varchar(255) NOT NULL DEFAULT '',
  `profile_name` varchar(32) NOT NULL DEFAULT '',
  `profile_update_timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `cscart_user_profiles`
--

INSERT INTO `cscart_user_profiles` (`profile_id`, `user_id`, `profile_type`, `b_firstname`, `b_lastname`, `b_address`, `b_address_2`, `b_city`, `b_county`, `b_state`, `b_country`, `b_zipcode`, `b_phone`, `s_firstname`, `s_lastname`, `s_address`, `s_address_2`, `s_city`, `s_county`, `s_state`, `s_country`, `s_zipcode`, `s_phone`, `s_address_type`, `profile_name`, `profile_update_timestamp`) VALUES
(1, 1, 'P', 'John', 'Doe', '44 Main street', 'test', 'Boston', '', 'MA', 'US', '02134', '', 'John', 'Doe', '44 Main street', 'test', 'Boston', '', 'MA', 'US', '02134', '', '', 'Main', 1661104455),
(2, 2, 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MA', 'US', '', '', '', 'Основной', 1661262682),
(3, 3, 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MA', 'US', '', '', '', 'Основной', 1661262729),
(4, 4, 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MA', 'US', '', '', '', 'Основной', 1661262813);

-- --------------------------------------------------------

--
-- Структура таблицы `cscart_user_session_products`
--

CREATE TABLE `cscart_user_session_products` (
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `type` char(1) NOT NULL DEFAULT 'C',
  `user_type` char(1) NOT NULL DEFAULT 'R',
  `item_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `item_type` char(1) NOT NULL DEFAULT 'P',
  `product_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `amount` mediumint(8) UNSIGNED NOT NULL DEFAULT 1,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `extra` blob DEFAULT NULL,
  `session_id` varchar(64) NOT NULL DEFAULT '',
  `ip_address` varbinary(40) NOT NULL DEFAULT '',
  `order_id` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `storefront_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `position` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `company_id` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cscart_units`
--
ALTER TABLE `cscart_units`
  ADD PRIMARY KEY (`unit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `cscart_unit_descriptions`
--
ALTER TABLE `cscart_unit_descriptions`
  ADD PRIMARY KEY (`unit_id`,`lang_code`);

--
-- Индексы таблицы `cscart_usergroups`
--
ALTER TABLE `cscart_usergroups`
  ADD PRIMARY KEY (`usergroup_id`),
  ADD KEY `c_status` (`usergroup_id`,`status`),
  ADD KEY `status` (`status`,`type`);

--
-- Индексы таблицы `cscart_usergroup_descriptions`
--
ALTER TABLE `cscart_usergroup_descriptions`
  ADD PRIMARY KEY (`usergroup_id`,`lang_code`);

--
-- Индексы таблицы `cscart_usergroup_links`
--
ALTER TABLE `cscart_usergroup_links`
  ADD PRIMARY KEY (`link_id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`usergroup_id`);

--
-- Индексы таблицы `cscart_users`
--
ALTER TABLE `cscart_users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_login` (`user_login`),
  ADD KEY `uname` (`firstname`,`lastname`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_last_activity` (`last_activity`);

--
-- Индексы таблицы `cscart_user_data`
--
ALTER TABLE `cscart_user_data`
  ADD PRIMARY KEY (`user_id`,`type`);

--
-- Индексы таблицы `cscart_user_mailing_lists`
--
ALTER TABLE `cscart_user_mailing_lists`
  ADD UNIQUE KEY `subscriber_list` (`list_id`,`subscriber_id`),
  ADD KEY `subscriber_id` (`subscriber_id`),
  ADD KEY `list_id` (`list_id`);

--
-- Индексы таблицы `cscart_user_profiles`
--
ALTER TABLE `cscart_user_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `uid_p` (`user_id`,`profile_type`),
  ADD KEY `profile_type` (`profile_type`);

--
-- Индексы таблицы `cscart_user_session_products`
--
ALTER TABLE `cscart_user_session_products`
  ADD PRIMARY KEY (`user_id`,`type`,`user_type`,`item_id`,`company_id`),
  ADD KEY `timestamp` (`timestamp`,`user_type`),
  ADD KEY `session_id` (`session_id`),
  ADD KEY `type` (`type`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cscart_units`
--
ALTER TABLE `cscart_units`
  MODIFY `unit_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `cscart_usergroups`
--
ALTER TABLE `cscart_usergroups`
  MODIFY `usergroup_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `cscart_usergroup_links`
--
ALTER TABLE `cscart_usergroup_links`
  MODIFY `link_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cscart_users`
--
ALTER TABLE `cscart_users`
  MODIFY `user_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `cscart_user_profiles`
--
ALTER TABLE `cscart_user_profiles`
  MODIFY `profile_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
